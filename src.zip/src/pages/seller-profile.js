import { t } from '../core/i18n/index.js';
import { api } from '../core/api/client.js';
import { requireAuth, hasAnyRole } from '../core/auth/index.js';
import { SELLER_ROLES } from '../shared/constants/roles.js';
import { showLoading, escapeHtml, observeAnimations } from '../core/utils/dom.js';
import { renderStars } from '../core/utils/format.js';
import { renderProductCards, showToast } from '../core/utils/ui.js';
import { setPageMeta } from '../core/utils/seo.js';

export default async function renderSellerProfile(container) {
  setPageMeta(t('seller.title'));
  const params = new URLSearchParams(location.hash.split('?')[1] || '');
  const userId = params.get('userId');
  if (userId) {
    showLoading(container);
    try {
      const profile = await api.get(`/seller-profile/${userId}`);
      container.innerHTML = `
        <div class="card mx-auto" style="max-width:600px">
          <div class="card-body">
          <div class="text-center mb-4">
            <i class="fas fa-store mb-2 fs-1 text-primary" aria-hidden="true"></i>
            <h2>${escapeHtml(profile.storeName)}</h2>
            ${profile.description ? `<p style="color:var(--text-secondary)">${escapeHtml(profile.description)}</p>` : ''}
          </div>
          <div class="d-flex gap-3 justify-content-center flex-wrap mb-3">
            ${profile.averageRating ? `<span><strong>${t('seller.rating')}:</strong> ${renderStars(profile.averageRating)} (${profile.averageRating.toFixed(1)})</span>` : ''}
            <span><strong>${t('seller.totalSales')}:</strong> ${profile.totalSales || 0}</span>
          </div>
          <div class="pt-3" style="border-top:1px solid var(--border);color:var(--text-secondary);font-size:0.88rem">
            ${profile.contactEmail ? `<p><i class="fas fa-envelope" aria-hidden="true"></i> ${escapeHtml(profile.contactEmail)}</p>` : ''}
            ${profile.contactPhone ? `<p><i class="fas fa-phone" aria-hidden="true"></i> ${escapeHtml(profile.contactPhone)}</p>` : ''}
            ${profile.location ? `<p><i class="fas fa-map-marker-alt" aria-hidden="true"></i> ${escapeHtml(profile.location)}</p>` : ''}
          </div>
        </div>
        </div>`;

    // Load seller's public product listings
    try {
      const sellerProducts = await api.get("/products", {
        SellerId: userId,
        PageSize: 8,
        Page: 1,
      });
      const items = sellerProducts.items || sellerProducts.data || [];
      if (items.length) {
        const productsSection = document.createElement("div");
        productsSection.style.marginTop = "32px";
        productsSection.innerHTML = `
          <div class="section-header">
            <h3><i class="fas fa-tag" aria-hidden="true"></i> ${t("seller.listings")}</h3>
          </div>
          <div class="product-card-grid product-card-grid-dense" id="sellerProductGrid"></div>
        `;
        container.appendChild(productsSection);
        renderProductCards(
          document.getElementById("sellerProductGrid"),
          items
        );
        observeAnimations();
      }
    } catch { /* inner products render failed */ }
    } catch {
      container.innerHTML = `<div class="empty-state"><i class="fas fa-store" aria-hidden="true"></i><h3>${t('seller.notFound')}</h3></div>`;
    }
    return;
  }

  if (!await requireAuth()) return;
  if (!hasAnyRole(...(SELLER_ROLES))) {
    container.innerHTML = `<div class="empty-state"><i class="fas fa-store" aria-hidden="true"></i><h3>${t('seller.noProfile')}</h3></div>`;
    return;
  }

  showLoading(container);

  try {
    const profile = await api.get('/seller-profile/me');
    renderForm(profile);
  } catch {
    renderForm(null);
  }

  function renderForm(profile) {
    const isNew = !profile;
    container.innerHTML = `
      <div class="section-header"><h2><i class="fas fa-store" aria-hidden="true"></i> ${isNew ? t('seller.create') : t('seller.myProfile')}</h2></div>
      <div id="sellerAlert"></div>
      <div class="card" style="max-width:520px">
        <div class="card-body">
        <form id="sellerForm" novalidate>
          <div class="form-group"><label class="form-label">${t('seller.storeName')} *</label><input type="text" class="form-input form-control" id="sStoreName" value="${escapeHtml(profile?.storeName || '')}" required></div>
          <div class="form-group"><label class="form-label">${t('seller.description')}</label><textarea class="form-textarea form-control" id="sDescription">${escapeHtml(profile?.description || '')}</textarea></div>
          <div class="form-group"><label class="form-label">${t('seller.contactEmail')}</label><input type="email" class="form-input form-control" id="sEmail" value="${escapeHtml(profile?.contactEmail || '')}"></div>
          <div class="form-group"><label class="form-label">${t('seller.contactPhone')}</label><input type="tel" class="form-input form-control" id="sPhone" value="${escapeHtml(profile?.contactPhone || '')}"></div>
          <div class="form-group"><label class="form-label">${t('seller.location')}</label><input type="text" class="form-input form-control" id="sLocation" value="${escapeHtml(profile?.location || '')}"></div>
          <button type="submit" class="btn btn-primary" id="sellerSubmit">${t('seller.save')}</button>
        </form>
        </div>
      </div>`;

    document.getElementById('sellerForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const submit = document.getElementById('sellerSubmit');
      submit.disabled = true;
      submit.innerHTML = `<i class="fas fa-spinner spinner" aria-hidden="true"></i> ${t('seller.saving')}`;
      const body = {
        storeName: document.getElementById('sStoreName').value.trim(),
        description: document.getElementById('sDescription').value.trim(),
        contactEmail: document.getElementById('sEmail').value.trim(),
        contactPhone: document.getElementById('sPhone').value.trim(),
        location: document.getElementById('sLocation').value.trim(),
      };
      try {
        if (isNew) {
          await api.post('/seller-profile', body);
        } else {
          await api.put('/seller-profile', body);
        }
        showToast(t('seller.saved'), 'success');
      } catch (err) {
        showToast(err.message, 'error');
      } finally {
        submit.disabled = false;
        submit.textContent = t('seller.save');
      }
    });
  }
}
