import { t } from '../core/i18n/index.js';
import { api } from '../core/api/client.js';
import { getUser } from '../core/auth/index.js';
import { escapeHtml } from '../core/utils/dom.js';
import { statusClass } from '../core/utils/format.js';
import { showToast } from '../core/utils/ui.js';
import { validateForm, clearFieldError } from '../core/utils/validation.js';
import { ROLES } from '../shared/constants/roles.js';

export default async function renderAuctionRequests(container) {
  const _u = getUser();
  if (!_u || _u.role !== ROLES.FISHERMAN) { window.location.hash = '#/'; return; }

  container.innerHTML = `
    <div class="section-header">
      <h2><i class="fas fa-gavel" aria-hidden="true"></i> ${t("auctionRequests.title")}</h2>
      <button class="btn btn-primary" id="newRequestBtn"><i class="fas fa-plus" aria-hidden="true"></i> ${t("auctionRequests.requestAuction")}</button>
    </div>
    <div id="auctionAlert"></div>
    <div id="auctionReqContent"><i class="fas fa-spinner spinner" aria-hidden="true"></i> ${t("common.loading")}</div>`;

  document.getElementById("newRequestBtn").addEventListener("click", () => {
    showForm(null);
  });

  await loadRequests();

  async function loadRequests() {
    const content = document.getElementById("auctionReqContent");
    try {
      const res = await api.get("/auctions/requests/my", { page: 1, pageSize: 50 });
      const items = res?.items || res?.data || [];
      if (!items || items.length === 0) {
        content.innerHTML = `<div class="empty-state"><i class="fas fa-gavel" aria-hidden="true"></i><h3>${t("auctionRequests.noRequests")}</h3><p>${t("auctionRequests.noRequestsDesc")}</p><button class="btn btn-primary" id="emptyRequestBtn"><i class="fas fa-plus" aria-hidden="true"></i> ${t("auctionRequests.requestAuction")}</button></div>`;
        document.getElementById("emptyRequestBtn")?.addEventListener("click", () => showForm(null));
        return;
      }
      content.innerHTML = `<div class="table-responsive"><table class="table"><thead><tr><th>${t("auctionRequests.productTitle")}</th><th>${t("auctionRequests.fishType")}</th><th>${t("auctionRequests.quantityKg")}</th><th>${t("auctionRequests.estimatedValue")}</th><th>${t("auctionRequests.status")}</th><th>${t("auctionRequests.createdAt")}</th>${t("auctionRequests.rejectionReason") ? `<th>${  t("auctionRequests.rejectionReason")  }</th>` : ''}</tr></thead><tbody>${items.map(r => `<tr><td>${escapeHtml(r.productTitle)}</td><td>${escapeHtml(r.fishType)}</td><td>${r.quantityKg}</td><td>${r.estimatedValue}</td><td><span class="${statusClass(r.status)}">${t(`auctionRequests.${  r.status.toLowerCase()}`)}</span></td><td>${new Date(r.createdAt).toLocaleDateString()}</td><td>${r.status === 'Rejected' ? escapeHtml(r.rejectionReason || '-') : '-'}</td></tr>`).join("")}</tbody></table></div>`;
    } catch (err) {
      content.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-triangle" aria-hidden="true"></i><h3>${t("common.error")}</h3><p>${escapeHtml(err.message)}</p></div>`;
    }
  }

  function showForm(existing) {
    const content = document.getElementById("auctionReqContent");
    content.innerHTML = `
      <div class="card" style="max-width:600px;margin-top:16px">
        <div class="card-header">
          <h3 class="mb-0">${existing ? t("auctionRequests.submit") : t("auctionRequests.submit")}</h3>
        </div>
        <div class="card-body">
        <form id="auctionReqForm" novalidate>
          <div class="form-group"><label class="form-label" for="arProductTitle">${t("auctionRequests.productTitle")} *</label><input type="text" class="form-input form-control" id="arProductTitle" value="${escapeHtml(existing?.productTitle || '')}" required></div>
          <div class="form-group"><label class="form-label" for="arFishType">${t("auctionRequests.fishType")} *</label><input type="text" class="form-input form-control" id="arFishType" value="${escapeHtml(existing?.fishType || '')}" required></div>
          <div class="form-group"><label class="form-label" for="arQuantityKg">${t("auctionRequests.quantityKg")} *</label><input type="number" step="0.01" min="0.01" class="form-input form-control" id="arQuantityKg" value="${existing?.quantityKg || ''}" required></div>
          <div class="form-group"><label class="form-label" for="arEstimatedValue">${t("auctionRequests.estimatedValue")} *</label><input type="number" step="0.01" min="0.01" class="form-input form-control" id="arEstimatedValue" value="${existing?.estimatedValue || ''}" required></div>
          <div class="form-group"><label class="form-label" for="arDescription">${t("auctionRequests.productDescription")}</label><textarea class="form-textarea form-control" id="arDescription">${escapeHtml(existing?.productDescription || '')}</textarea></div>
          <div class="form-group"><label class="form-label" for="arCatchLocation">${t("auctionRequests.catchLocation")}</label><input type="text" class="form-input form-control" id="arCatchLocation" value="${escapeHtml(existing?.catchLocation || '')}"></div>
          <div class="form-group"><label class="form-label" for="arCatchDate">${t("auctionRequests.catchDate")}</label><input type="date" class="form-input form-control" id="arCatchDate" value="${existing?.catchDate ? existing.catchDate.split('T')[0] : ''}"></div>
          <div class="form-group"><label class="form-label" for="arImageUrl">${t("auctionRequests.imageUrl")}</label><input type="url" class="form-input form-control" id="arImageUrl" value="${escapeHtml(existing?.imageUrl || '')}" placeholder="${t("auctionRequests.imageUrlHelp")}"></div>
          <p style="font-size:0.85rem;color:var(--text-muted)">${t("auctionRequests.imageUrlHelp")}</p>
          <div class="d-flex gap-2 mt-3">
            <button type="submit" class="btn btn-primary" id="arSubmit">${t("auctionRequests.submit")}</button>
            <button type="button" class="btn btn-ghost" id="arCancel">${t("common.cancel")}</button>
          </div>
        </form>
        </div>
      </div>`;

    const titleIn = document.getElementById("arProductTitle");
    const fishIn = document.getElementById("arFishType");
    const qtyIn = document.getElementById("arQuantityKg");
    const estIn = document.getElementById("arEstimatedValue");

    [titleIn, fishIn, qtyIn, estIn].forEach(el => {
      el.addEventListener("input", () => clearFieldError(el));
    });

    document.getElementById("arCancel").addEventListener("click", () => loadRequests());
    document.getElementById("auctionReqForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const form = e.target;

      const valid = validateForm(form, [
        { element: titleIn, required: true },
        { element: fishIn, required: true },
        { element: qtyIn, required: true, min: 0.01 },
        { element: estIn, required: true, min: 0.01 },
      ]);

      if (!valid) return;

      const submit = document.getElementById("arSubmit");
      submit.disabled = true;
      submit.innerHTML = `<i class="fas fa-spinner spinner" aria-hidden="true"></i> ${t("auctionRequests.submitting")}`;
      const body = {
        productTitle: titleIn.value.trim(),
        productDescription: document.getElementById("arDescription").value.trim(),
        estimatedValue: parseFloat(estIn.value),
        quantityKg: parseFloat(qtyIn.value),
        fishType: fishIn.value.trim(),
        catchLocation: document.getElementById("arCatchLocation").value.trim(),
        catchDate: document.getElementById("arCatchDate").value || null,
        productImageUrl: document.getElementById("arImageUrl").value.trim() || null,
      };
      try {
        await api.post("/auctions/requests", body);
        showToast(t("auctionRequests.submitted"), "success");
        loadRequests();
      } catch (err) {
        showToast(err.message, "error");
      } finally {
        submit.disabled = false;
        submit.textContent = t("auctionRequests.submit");
      }
    });
  }
}
